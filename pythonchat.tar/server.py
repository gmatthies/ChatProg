import sys
from PyQt4.QtGui  import *
from PyQt4.QtCore import *
from PyQt4.QtNetwork import *
 
class Server(QWidget):
   def __init__(self, parent=None):
      super(Server, self).__init__(parent)
 
      self.lay = QVBoxLayout(self)
      self.display = QTextBrowser()
      self.display.setFocusPolicy(Qt.NoFocus)
      self.lay.addWidget(self.display)
      self.lineedit= QLineEdit()
      self.lay.addWidget(self.lineedit)
 
      self.tcpServer = QTcpServer()
      host = QHostAddress("0.0.0.0")
      self.tcpServer.listen(host, 2222)
      if not self.tcpServer.isListening():
         QMessageBox.critical(self, "Server", "Unable To Start Server!")
         exit()
      else:
         self.display.append("SERVER:" + self.tcpServer.serverAddress().toString())
         self.display.append("PORT  :" + str(self.tcpServer.serverPort()))
 
      QObject.connect(self.tcpServer, SIGNAL("newConnection()"), self.newConnectionArrives )
      QObject.connect(self.lineedit, SIGNAL("returnPressed()"), self.lineeditReturnPressed )
 
#---------------------------------------------
   def lineeditReturnPressed(self):
      txt = "SERVER> " + str(self.lineedit.text())
      self.display.append(txt)
      self.sock.write(QByteArray(txt))
      self.lineedit.clear()
#---------------------------------------------
   def newConnectionArrives(self):
      self.sock = self.tcpServer.nextPendingConnection()
      QObject.connect( self.sock, SIGNAL("readyRead()"), self.tcpSocketReadyReadEmitted )
#---------------------------------------------
   def tcpSocketReadyReadEmitted(self):
      txt = str(self.sock.readAll())
      self.display.append(txt)
 
##############################################
### Main script
if __name__ == "__main__":
   app = QApplication(sys.argv)
   myapp = Server()
   myapp.show()
   sys.exit(app.exec_())
