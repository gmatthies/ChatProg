import sys
import subprocess
from PyQt4.QtGui  import *
from PyQt4.QtCore import *
from PyQt4.QtNetwork import *
 
class Client(QWidget):
   def __init__(self, host, port):
      super(Client, self).__init__(None)
 
      self.lay = QVBoxLayout(self)
      self.display = QTextBrowser()
      self.display.setFocusPolicy(Qt.NoFocus)
      self.lay.addWidget(self.display)
      self.lineedit= QLineEdit()
      self.lay.addWidget(self.lineedit)
 
      self.tcpSocket = QTcpSocket()
      self.tcpSocket.connectToHost(host, int(port))
 
      QObject.connect(self.lineedit, SIGNAL("returnPressed()"), self.lineeditReturnPressed )
      QObject.connect(self.tcpSocket, SIGNAL("readyRead()"), self.tcpSocketReadyReadEmitted)
      QObject.connect(self.tcpSocket, SIGNAL("connected()"), self.tcpSocketConnected)
#---------------------------------------------
   def tcpSocketReadyReadEmitted(self):
      txt = str(self.tcpSocket.readAll())
      self.display.append(txt)
#---------------------------------------------
   def lineeditReturnPressed(self):
      txt = "CLIENT> " + str(self.lineedit.text())
      self.tcpSocket.write(QByteArray(txt))
      self.display.append(txt)
      self.lineedit.clear()
#---------------------------------------------
   def tcpSocketConnected(self):
      txt = "Successfully connected to Server!!!"
      self.display.append(txt)
      self.tcpSocket.write(QByteArray(txt))
 
##############################################
### Main script
if __name__ == "__main__":
      app = QApplication(sys.argv)
      myapp = Client(sys.argv[1], sys.argv[2])
      myapp.show()
      sys.exit(app.exec_())
